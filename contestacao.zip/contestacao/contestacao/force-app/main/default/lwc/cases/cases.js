import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import { NavigationMixin } from'lightning/navigation';


const FIELDS = [
    'Case.LogicNumber__c',
    'Case.LogicNumber__r.Name',
    'Case.CurrencyType__c',
    'Case.ContactCPF__c',
    'Case.SenderName__c',
    'case.BankTransaction__c',
    'case.SenderCPF__c',
    'case.Bank__c',
    'Case.Bank__r.Name',
    'case.BankTransactionSender__c',
    'case.BankTransactionSender__r.Name',
    'case.Agency__c',
    'case.SenderAgency__c',
    'case.BankingAccount__c',
    'case.SenderBankAccount__c',
    'case.DateHourTransaction__c',
    'case.ReceiverName__c',
    'case.Operator__c',
    'case.ReceiverCPF__c',
    'case.TransactionRealizedWithCardOperator__c',
    'case.BankTransactionReceiver__c',
    'case.BankTransactionReceiver__r.Name',
    'case.CardOperatorNumber__c',
    'case.ReceiverAgency__c',
    'case.CardFourDigits__c',
    'case.ReceiverBankAccount__c',
    'case.TransportCardNumber__c',
    'case.PaymentRealizedWith__c',
    'case.InsertedAmount__c',
    'case.ReloadRealizedWith__c',
    'case.PaymentSlipNumber__c',
    'case.DepositIn__c',
    'case.PaymentSlipAmount__c',
    'case.TransactionTypeContestation__c',
    'case.InsertedAmountEstimated__c',
    'case.ClientHasReceipt__c',
    'case.RejectedReturnedAmount__c',
    'case.NSU_BDO__c',
    'case.ConfirmedAmount__c',
    'case.SackingType__c',
    'case.CheckAmount__c',
    'case.Currency__c',
    'case.DispensedAmount__c',
    'case.Institution__c',
    'case.TransactionAmount__c',
    'case.PhoneOperator__c',
    'case.ReloadAmount__c',
    'case.ForeignOperator__c',
    'case.InsertedAmountEstimated__c',
    'case.RequestedAmount__c',
    'case.ContestedAmount__c',
    'case.ContestedAmount1__c'

];

export default class cases extends NavigationMixin(LightningElement) {
    @api recordId;
    
    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    myCase;

    navigateToRecordViewPage(event) {
        this[NavigationMixin.Navigate]({
            type:'standard__recordPage', 
            attributes:{
                recordId:event.target.dataset.id,
                actionName:'view'
            }       
        });    
    }
    isSelected = false
    handleToggleSection() {
        this.isSelected = !this.isSelected;
        this.template.querySelector('[data-id="collapsibleSectionContainer"]').classList.toggle('slds-is-open');
    }

    get LogicNumber__c() {
        return this.myCase.data.fields.LogicNumber__c.value;
    }
    get LogicNumberName() {        
        return this.myCase.data.fields.LogicNumber__r.value.fields.Name.value;    
    }
    get CurrencyType__c() {
        return this.myCase.data.fields.CurrencyType__c.value;
    }
    get RenderLinha1() {
        return this.LogicNumber__c || this.CurrencyType__c;
    }
    get ContactCPF__c() {
        return this.myCase.data.fields.ContactCPF__c.value;
    }
    get SenderName__c() {
        return this.myCase.data.fields.SenderName__c.value;
    }
    get RenderLinha2() {
        return this.ContactCPF__c || this.SenderName__c;
    }
    get BankTransaction__c() {
        return this.myCase.data.fields.BankTransaction__c.value;
    }
    get SenderCPF__c() {
        return this.myCase.data.fields.SenderCPF__c.value;
    }
    get RenderLinha3() {
        return this.BankTransaction__c || this.SenderCPF__c;
    }
    get Bank__c() {
        return this.myCase.data.fields.Bank__c.value;
    }
    get BankName() {        
        return this.myCase.data.fields.Bank__r.value.fields.Name.value;    
    }
    get BankTransactionSender__c() {
        return this.myCase.data.fields.BankTransactionSender__c.value;
    }
    get BankTransactionSenderName() {
        return this.myCase.data.fields.BankTransactionSender__r.value.fields.Name.value;
    }
    get RenderLinha4() {
        return this.Bank__c || this.BankTransactionSender__c;
    }
    get Agency__c() {
        return this.myCase.data.fields.Agency__c.value;
    }
    get SenderAgency__c() {
        return this.myCase.data.fields.SenderAgency__c.value;
    }
    get RenderLinha5() {
        return this.Agency__c || this.SenderAgency__c;
    }
    get BankingAccount__c() {
        return this.myCase.data.fields.BankingAccount__c.value;
    }
    get SenderBankAccount__c() {
        return this.myCase.data.fields.SenderBankAccount__c.value;
    }
    get RenderLinha6() {
        return this.BankingAccount__c || this.SenderBankAccount__c;
    }
    get DateHourTransaction__c() {
        return this.myCase.data.fields.DateHourTransaction__c.value;
    }
    get ReceiverName__c() {
        return this.myCase.data.fields.ReceiverName__c.value;
    }
    get RenderLinha7() {
        return this.DateHourTransaction__c || this.ReceiverName__c;
    }
    get Operator__c() {
        return this.myCase.data.fields.Operator__c.value;
    }
    get ReceiverCPF__c() {
        return this.myCase.data.fields.ReceiverCPF__c.value;
    }
    get RenderLinha8() {
        return this.Operator__c || this.ReceiverCPF__c;
    }
    get TransactionRealizedWithCardOperator__c() {
        return this.myCase.data.fields.TransactionRealizedWithCardOperator__c.value;
    }
    get BankTransactionReceiver__c() {
        return this.myCase.data.fields.BankTransactionReceiver__c.value;
    }
    get BankTransactionReceiverName() {
        return this.myCase.data.fields.BankTransactionReceiver__r.value.fields.Name.value;

    }
    get RenderLinha9() {
        return this.TransactionRealizedWithCardOperator__c || this.BankTransactionReceiver__c;
    }
    get CardOperatorNumber__c() {
        return this.myCase.data.fields.CardOperatorNumber__c.value;
    }
    get ReceiverAgency__c() {
        return this.myCase.data.fields.ReceiverAgency__c.value;
    }
    get RenderLinha10() {
        return this.CardOperatorNumber__c || this.ReceiverAgency__c;
    }
    get CardFourDigits__c() {
        return this.myCase.data.fields.CardFourDigits__c.value;
    }
    get ReceiverBankAccount__c() {
        return this.myCase.data.fields.ReceiverBankAccount__c.value;
    }
    get RenderLinha11() {
        return this.CardFourDigits__c || this.ReceiverBankAccount__c;
    }
    get TransportCardNumber__c() {
        return this.myCase.data.fields.TransportCardNumber__c.value;
    }
    get PaymentRealizedWith__c() {
        return this.myCase.data.fields.PaymentRealizedWith__c.value;
    }
    get RenderLinha12() {
        return this.TransportCardNumber__c || this.PaymentRealizedWith__c
    }
    get InsertedAmount__c() {
        return this.myCase.data.fields.InsertedAmount__c.value;
    }
    get ReloadRealizedWith__c() {
        return this.myCase.data.fields.ReloadRealizedWith__c.value;
    }
    get RenderLinha13() {
        return this.InsertedAmount__c || this.ReloadRealizedWith__c
    }
    get PaymentSlipNumber__c() {
        return this.myCase.data.fields.PaymentSlipNumber__c.value;
    }
    get DepositIn__c() {
        return this.myCase.data.fields.DepositIn__c.value;
    }
    get RenderLinha14() {
        return this.PaymentSlipNumber__c || this.DepositIn__c;
    }
    get PaymentSlipAmount__c() {
        return this.myCase.data.fields.PaymentSlipAmount__c.value;
    }
    get TransactionTypeContestation__c() {
        return this.myCase.data.fields.TransactionTypeContestation__c.value;
    }
    get RenderLinha15() {
        return this.PaymentSlipAmount__c || this.TransactionTypeContestation__c;
    }
    get InsertedAmountEstimated__c() {
        return this.myCase.data.fields.InsertedAmountEstimated__c.value;
    }
    get ClientHasReceipt__c() {
        return this.myCase.data.fields.ClientHasReceipt__c.value;
    }
    get RenderLinha16() {
        return this.InsertedAmountEstimated__c || this.ClientHasReceipt__c;
    }
    get RejectedReturnedAmount__c() {
        return this.myCase.data.fields.RejectedReturnedAmount__c.value;
    }
    get NSU_BDO__c() {
        return this.myCase.data.fields.NSU_BDO__c.value;
    }
    get RenderLinha17() {
        return this.RejectedReturnedAmount__c || this.NSU_BDO__c;
    }
    get ConfirmedAmount__c() {
        return this.myCase.data.fields.ConfirmedAmount__c.value;
    }
    get SackingType__c() {
        return this.myCase.data.fields.SackingType__c.value;
    }
    get RenderLinha18() {
        return this.ConfirmedAmount__c || this.SackingType__c;
    }
    get CheckAmount__c() {
        return this.myCase.data.fields.CheckAmount__c.value;
    }
    get Currency__c() {
        return this.myCase.data.fields.Currency__c.value;
    }
    get RenderLinha19() {
        return this.CheckAmount__c || this.Currency__c;
    }
    get DispensedAmount__c() {
        return this.myCase.data.fields.DispensedAmount__c.value;
    }
    get Institution__c() {
        return this.myCase.data.fields.Institution__c.value;
    }
    get RenderLinha20() {
        return this.DispensedAmount__c || this.Institution__c;
    }
    get TransactionAmount__c() {
        return this.myCase.data.fields.TransactionAmount__c.value;
    }
    get PhoneOperator__c() {
        return this.myCase.data.fields.PhoneOperator__c.value;
    }
    get RenderLinha21() {
        return this.TransactionAmount__c || this.PhoneOperator__c;
    }
    get ReloadAmount__c() {
        return this.myCase.data.fields.ReloadAmount__c.value;
    }
    get ForeignOperator__c() {
        return this.myCase.data.fields.ForeignOperator__c.value;
    }
    get RenderLinha22() {
        return this.ReloadAmount__c || this.ForeignOperator__c;
    }
    get InsertedAmountEstimated__c() {
        return this.myCase.data.fields.InsertedAmountEstimated__c.value;
    }
    get RenderLinha23() {
        return this.InsertedAmountEstimated__c;
    }
    get RequestedAmount__c() {
        return this.myCase.data.fields.RequestedAmount__c.value;
    }
    get RenderLinha24() {
        return this.RequestedAmount__c;
    }
    get ContestedAmount__c() {
        return this.myCase.data.fields.ContestedAmount__c.value;
    }
    get RenderLinha25() {
        return this.ContestedAmount__c;
    }
    get ContestedAmount1__c() {
        return this.myCase.data.fields.ContestedAmount1__c.value;
    }
    get RenderLinha26() {
        return this.ContestedAmount1__c;
    }

}